###PYTHON TUPLES
#
thistuple=('appel', 'banana', 'cherry', 'apple')
'''print(thistuple)
print(len(thistuple))'''

# crea una tupla con un elemento
'''thistuple=('apple',)
print(type(thistuple))'''

#crear con constructor
'''thistuple=tuple(('apple', 'banana', 'cherry'))
print(thistuple)
print(thistuple[1])
print(thistuple[-1])
print(thistuple[2:3])'''

'''x=('apple', 'banana', 'cherry')
y=list(x)
y[1]='kiwi'
x=tuple(y)
print(x)'''
#unpack tuples
fruits=('apple', 'banana', 'cherry')

(green, yellow, red)=fruits
print(green)
print(yellow)
print(red)



