### PYTHON LISTS
## los elementos de una lista son ordenaodos
#todo elemento tiene un indice
'''
mylist={'Apple', 'Bannana', 'Cherry'}
print(mylist)
print(len(mylist))
list1={'apple', 'bannana','cherry'}
list2={1,6,3,9,5,7}
list3={True, False, False}

lista={'abc', 34, True, 40.2, 'male'}

print(type(lista))

#crea una lista mediante constructor
thislist=list(('Apple', 'bannana', 'cherry'))'''

#Acceder a elementos
'''thislist=['Apple', 'bannana', 'cherry', 'orange', 'kiwi', 'melon', 'mango']
print(thislist[2:])
if 'bannana' in thislist:
  print('Si existe')'''

'''thislist[1:3]=['blackcurrant', 'watermelon']
print(thislist)'''

'''thislist=['orenage', 'mango', 'kwi', 'Apple', 'bannana', 'cherry']
thislist[1:2]=['blackcurrant', 'watermelon']
print(thislist)'''
'''thislist.insert(2, 'watermelon')
print(thislist)'''
'''thislist.insert(1, 'orange')
print(thislist)'''
'''tropical=['mango', 'pineapple', 'papaya']
print(thislist)
thislist.extend(tropical)
print(thislist)'''
'''thistuple=('kiwi', 'orange')
thislist.extend(thistuple)
print(thislist)'''
'''thislist.remove('bannana')
print(thislist)'''
'''thislist.pop(1)
print(thislist)'''
'''del thislist[0]
print(thislist)'''
'''thislist.clear()
print(thislist)'''
'''for x in thislist:
  print(x)'''
'''for i in range(len(thislist)):
  print(thislist[i])'''
'''thislist.sort()
print(thislist)'''
'''thislist.sort(reverse=True)
print(thislist)'''
thislist=['bannna', 'Orange', 'Kiwi','cherry']
thislist.sort()
print(thislist)



