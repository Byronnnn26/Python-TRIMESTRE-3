from fastapi import FastAPI, HTTPException
from typing import List
from models import Jugador, JugadorCreate

app = FastAPI()
app.title = '2924760 - Bayron Lopez'

# (simulando base de datos)
jugadores_db = []

# post (crea un nuevo jugador)
@app.post("/jugadores/", tags = ['Jugadores'] ,response_model=Jugador)
async def crear_jugador(jugador: JugadorCreate):
    id_nuevo = len(jugadores_db) + 1
    nuevo_jugador = Jugador(id=id_nuevo, **jugador.dict())
    jugadores_db.append(nuevo_jugador)
    return nuevo_jugador

# get (ven los jugadores)
@app.get("/jugadores/",tags = ['Jugadores'] , response_model=List[Jugador])
async def obtener_jugadores():
    return jugadores_db

# get2(ver juagador por id)
@app.get("/jugadores/{jugador_id}",tags = ['Jugadores'] , response_model=Jugador)
async def obtener_jugador(jugador_id: int):
    jugador = next((p for p in jugadores_db if p.id == jugador_id), None)
    if jugador is None:
        raise HTTPException(status_code=404, detail="Jugadores no encontrado")
    return jugador

# put (actualiza)
@app.put("/jugadores/{jugador_id}",tags = ['Jugadores'] , response_model=Jugador)
async def actualizar_jugador(jugador_id: int, jugador_actualizado: JugadorCreate):
    jugador = next((p for p in jugadores_db if p.id == jugador_id), None)
    if jugador is None:
        raise HTTPException(status_code=404, detail="Jugadores no encontrado")
    
    jugador.nombre = jugador_actualizado.nombre
    jugador.descripcion = jugador_actualizado.descripcion
    jugador.precio = jugador_actualizado.precio
    return jugador

# delete(elimina)
@app.delete("/jugadores/{jugador_id}",tags = ['Jugadores'] , response_model=Jugador)
async def eliminar_jugador(jugador_id: int):
    jugador = next((p for p in jugadores_db if p.id == jugador_id), None)
    if jugador is None:
        raise HTTPException(status_code=404, detail="Jugadores no encontrado")
    
    jugadores_db.remove(jugador)
    return jugador