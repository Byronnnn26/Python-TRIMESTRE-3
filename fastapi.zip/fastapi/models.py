from pydantic import BaseModel

# datos para el Jugador
class Jugador(BaseModel):
    id: int
    nombre: str
    posición:str
    edad: str
    equipo: str

# Modelo de entrada (sin id, ya que se asignará automáticamente
class JugadorCreate(BaseModel):
    nombre: str
    posición:str
    edad: str
    equipo: str